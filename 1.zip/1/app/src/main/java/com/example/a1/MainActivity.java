package com.example.a1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import org.json.JSONArray;
import org.json.JSONException;

import java.net.URL;

public class MainActivity extends AppCompatActivity {

    EditText numero;
    TextView cubo,cubico,raiz_cuadrada,raiz_cubica;
    Button buscar;
    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        relacionamosVistas();
    }
buscar.setOnClickListener((v) → {
           buscarnumero( URL: "http://localhost/phpmyadmin/index.php?route=/sql&db=trabajoleal&table=operacionesmatematicas&pos=0"+e5.getText()+"");
        });


    }
    public void relacionamosVistas(){
        e1=(EditText)findViewById(R.id.nombre);
        e2=(TextView)findViewById(R.id.cuadrado);
        e3=(TextView)findViewById(R.id.cubico);
        e4=(TextView)findViewById(R.id.raiz_cuadrada);
        e5=(TextView)findViewById(R.id.raiz_cubica);
        buscar=(Button) findViewById(R.id.buscar);
    }

    private void buscarnumero (String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, onResponse(onresponse) )
    }
}